import { Component } from "@angular/core";

@Component ({
    selector : 'app-recipeitem',
    templateUrl : './recipeitem.component.html',
    styleUrls : ['./recipeitem.component.css']
})

export class RecipeItemComponent {}
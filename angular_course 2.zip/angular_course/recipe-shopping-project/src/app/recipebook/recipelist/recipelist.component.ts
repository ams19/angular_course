import { Component } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component ({
    selector : 'app-recipelist',
    templateUrl : './recipelist.component.html',
    styleUrls : ['./recipelist.component.css']
})

export class RecipeListComponent {
    
    recipes : Recipe[] = [new Recipe("First recipe","This is my first recipe.","https://images.unsplash.com/photo-1547592180-85f173990554?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"),
    new Recipe("First recipe","This is my first recipe.","https://images.unsplash.com/photo-1547592180-85f173990554?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80")];

    constructor() {}
}
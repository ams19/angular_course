import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RecipedetailsComponent } from './recipebook/recipedetails/recipedetails.component';
import { HeaderComponent } from './header/header.component';
import { RecipeBookComponent } from './recipebook/recipebook.component';
import { RecipeListComponent } from './recipebook/recipelist/recipelist.component';
import { RecipeItemComponent } from './recipebook/recipelist/recipeitem/recipeitem.component';
import { ShoppinglistComponent } from './shoppinglist/shoppinglist.component';
import { ShoppingeditComponent } from './shoppinglist/shoppingedit/shoppingedit.component';

@NgModule({
  declarations: [
    AppComponent,
    RecipedetailsComponent,
    HeaderComponent,
    RecipeBookComponent,
    RecipeListComponent,
    RecipeItemComponent,
    ShoppinglistComponent,
    ShoppingeditComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component } from '@angular/core';

@Component ({
    selector: 'warning-alert',
    templateUrl: './warningalert.component.html',
    styleUrls: ['./warningalert.component.css']
})

export class WarningComponent{}
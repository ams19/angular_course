import { preserveWhitespacesDefault } from '@angular/compiler';
import { isNull } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})

export class ServersComponent implements OnInit {
allowNewServer= false;
newServerStatus = "No server created!";
serverName = "Default Value";
isServerCreated = false;
username;
isUsernameEmpty = true; 
servers = ['Server1' , 'server2'];
displayDetails = false;
clickCounter = 0;
buttonClicks = [];
  constructor() {
    setTimeout(()=>{
      this.allowNewServer = true;
    },2000);
  }

  onServerCreation() {
    this.newServerStatus = "Server created";
    this.isServerCreated = true;
    this.servers.push(this.serverName);
    console.log(this.servers);
  }

  onServerNameUpdate(event: Event) {
    this.serverName = (<HTMLInputElement>event.target).value;
  }

  resetUsername(event: any) {
    this.username = null;
    this.isUsernameEmpty = true;
  }

  getIsUsernameEmpty(event: any) {
    if(event.target.value.length == 0) {
      this.isUsernameEmpty = true;
    }
    else {
      this.isUsernameEmpty = false;
    }
  }

  toggleDetails() {
    this.displayDetails = !this.displayDetails;
    this.clickCounter++;
    this.buttonClicks.push(new Date);
  }

  ngOnInit(): void {
  }

}
